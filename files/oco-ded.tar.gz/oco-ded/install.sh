#!/bin/bash


CAT="cat"
GREP="grep"
MKDIR="mkdir"
CP="cp"
PERL="perl"
DATE="date"


if [ ! -e "./itsgr8" ]; then

	echo "You must run 'install.sh' from source directory."
	exit 1
else


	PREFIX="/usr/local/oco"

	RESULTDIR=$PREFIX"/result"
	RESULTDEBUGDIR=$PREFIX"/result_debug"
	BINDIR=$PREFIX"/bin"
	LOCKDIR=$PREFIX"/lock"

	$MKDIR -p $RESULTDIR
	$MKDIR -p $RESULTDEBUGDIR
	$MKDIR -p $BINDIR
	$MKDIR -p $LOCKDIR
	$MKDIR -p /var/log/oco
	
	$CP -vfr ./bin/* $BINDIR


	#remove old entries in /etc/crontab 
	sec60=`$GREP "\*/1 \* \* \* \* root run-parts $BINDIR/60sec >/dev/null 2>/dev/null" /etc/crontab`
	sec120=`$GREP "\*/2 \* \* \* \* root run-parts $BINDIR/120sec >/dev/null 2>/dev/null" /etc/crontab`
	sec300=`$GREP "\*/5 \* \* \* \* root run-parts $BINDIR/300sec >/dev/null 2>/dev/null" /etc/crontab`
	
	if [ -n "sec60" -o -n "sec120" -o -n "sec300" ]; then
		now=`$DATE +%Y-%m-%d`
		$CP /etc/crontab /etc/crontab.${now}.bak
		$GREP -v "root run-parts $BINDIR/" /etc/crontab.${now}.bak > /etc/crontab
	fi
	
	
	#add crontab entries
	echo "*/1 * * * * root run-parts $BINDIR/60sec >/dev/null 2>/dev/null" > /etc/cron.d/oco
	echo "*/2 * * * * root run-parts $BINDIR/120sec >/dev/null 2>/dev/null" >>/etc/cron.d/oco
	echo "*/5 * * * * root run-parts $BINDIR/300sec >/dev/null 2>/dev/null" >>/etc/cron.d/oco


	if [ -f /etc/gentoo-release ]
	then
		$CP $BINDIR/oco.gentoo /etc/init.d/oco
		rc-update add oco default
		/etc/init.d/oco restart
	else
		if [ -d "/etc/rc.d" ]; then
			PREFIX_INITD="/etc/rc.d"
		else
			PREFIX_INITD="/etc"
		fi

		$CP $BINDIR/oco $PREFIX_INITD/init.d/oco

		[ -e "$PREFIX_INITD/rc2.d/S98oco" ] || ln -sfn ../init.d/oco $PREFIX_INITD/rc2.d/S98oco
		[ -e "$PREFIX_INITD/rc3.d/S98oco" ] || ln -sfn ../init.d/oco $PREFIX_INITD/rc3.d/S98oco
		$PREFIX_INITD/init.d/oco restart
	fi
fi


